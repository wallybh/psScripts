function teste
{
	write-warning $MyInvocation.MyCommand.Path
}