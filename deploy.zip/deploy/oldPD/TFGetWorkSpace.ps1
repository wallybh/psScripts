. .\LoadConfig

LoadConfig .\app.config

.\Invoke-TFSGet $appSettings['PATHWORKSPACE']