param
(
	[String]
	$path,
	[String]
	$server
)

tf get $path  /recursive